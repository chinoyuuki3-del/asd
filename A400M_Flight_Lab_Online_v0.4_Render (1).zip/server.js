'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {WebSocketServer,WebSocket} = require('ws');
const root = path.join(__dirname,'public');
const users = new Map(), sockets = new Map(), rooms = new Map(), invites = new Map(), friendRequests = new Map();
const MIME={'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.mp3':'audio/mpeg','.gz':'application/gzip','.png':'image/png','.jpg':'image/jpeg','.json':'application/json; charset=utf-8'};
const validCode=s=>typeof s==='string' && /^[A-Z0-9]{8}$/.test(s);
function send(ws,msg){if(ws?.readyState===WebSocket.OPEN)ws.send(JSON.stringify(msg));}
function deliver(code,msg){send(sockets.get(code),msg);}
function fail(ws,reason){send(ws,{type:'error',reason});}
function makeCode(token){return crypto.createHash('sha256').update(token).digest('hex').slice(0,8).toUpperCase();}
function profile(u){return {code:u.code,name:u.name,online:!!sockets.get(u.code)};}
function look(code){return [...users.values()].find(x=>x.code===code);}
function publicFriends(u){return [...u.friends].map(code=>{const p=look(code);return p?profile(p):{code,name:code,online:false};});}
function broadcastFriends(u){send(sockets.get(u.code),{type:'friends',list:publicFriends(u)});for(const code of u.friends){const p=look(code);if(p)send(sockets.get(p.code),{type:'presence',user:profile(u)});}}
function peer(room,code){return room.a===code?room.b:room.a;}
function inRoom(u){return u.room&&rooms.get(u.room);}
function roomState(room){return {id:room.id,mode:room.mode,phase:room.phase,host:room.a,guest:room.b,planes:room.planes,course:room.course,chosenCourses:room.chosenCourses};}
function syncRoom(room){for(const code of [room.a,room.b])deliver(code,{type:'room',room:roomState(room)});}
function endRoom(room,by){if(!room)return;rooms.delete(room.id);for(const code of [room.a,room.b]){const u=look(code);if(u?.room===room.id)u.room=null;deliver(code,{type:'room_closed',by});}}
const server=http.createServer((req,res)=>{
 if(req.url?.split('?')[0]==='/health'){res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify({ok:true,online:sockets.size,rooms:rooms.size}));return;}
 let pathname;try{pathname=decodeURIComponent((req.url||'/').split('?')[0]);}catch{res.writeHead(400);res.end();return;}
 if(pathname==='/'||pathname==='/index.html')pathname='/index.html';
 const f=path.resolve(root,'.'+pathname);
 if(!(f===root||f.startsWith(root+path.sep))){res.writeHead(403);res.end();return;}
 fs.stat(f,(err,st)=>{
  if(err||!st.isFile()){res.writeHead(404);res.end('Not found');return;}
  const ext=path.extname(f);res.writeHead(200,{'Content-Type':MIME[ext]||'application/octet-stream','Content-Length':st.size,'Cache-Control':ext==='.html'?'no-cache':'public, max-age=86400','X-Content-Type-Options':'nosniff'});
  fs.createReadStream(f).pipe(res);
 });
});
const wss=new WebSocketServer({server,path:'/ws',maxPayload:4096,perMessageDeflate:false});
wss.on('connection',ws=>{
 let user=null;ws.isAlive=true;ws.on('pong',()=>ws.isAlive=true);
 ws.on('message',raw=>{
  let msg;try{msg=JSON.parse(String(raw));}catch{return fail(ws,'不正な通信です');}
  if(!msg||typeof msg.type!=='string')return;
  if(msg.type==='hello'){
   if(user)return;
   if(typeof msg.token!=='string'||!/^[a-f0-9]{32,64}$/.test(msg.token))return fail(ws,'認証情報を確認してください');
   let code=makeCode(msg.token);while(look(code)&&look(code).token!==msg.token)code=code.slice(0,6)+crypto.randomBytes(1).toString('hex').toUpperCase();
   user=users.get(msg.token);
   if(!user){user={token:msg.token,code,name:'Pilot',friends:new Set(),room:null,lastState:0,lastPulse:0,lastChat:0,lastInvite:0,friendClaims:new Set()};users.set(msg.token,user);}
   const prev=sockets.get(user.code);if(prev&&prev!==ws){send(prev,{type:'replaced'});prev.close();}
   sockets.set(user.code,ws);
   user.name=(String(msg.name||user.name).trim().slice(0,18)||'Pilot').replace(/[<>]/g,'');
   user.friendClaims=new Set((Array.isArray(msg.friends)?msg.friends:[]).filter(validCode).slice(0,200));
   for(const other of users.values())if(other!==user&&user.friendClaims.has(other.code)&&other.friendClaims?.has(user.code)){user.friends.add(other.code);other.friends.add(user.code);broadcastFriends(other);}
   send(ws,{type:'hello',me:profile(user),friends:publicFriends(user),room:inRoom(user)?roomState(inRoom(user)):null});broadcastFriends(user);return;
  }
  if(!user)return fail(ws,'最初に名前を登録してください');
  if(msg.type==='rename'){user.name=String(msg.name||'Pilot').trim().slice(0,18).replace(/[<>]/g,'')||'Pilot';deliver(user.code,{type:'me',me:profile(user)});broadcastFriends(user);return;}
  if(msg.type==='friend_add'){
   const to=String(msg.code||'').toUpperCase();const target=look(to);
   if(!validCode(to)||!target||!sockets.get(to)||to===user.code)return fail(ws,'そのフレンドコードは現在オンラインではありません');
   if(user.friends.has(to))return fail(ws,'すでにフレンドです');
   friendRequests.set(to+':'+user.code,Date.now()+120000);deliver(to,{type:'friend_request',from:profile(user)});send(ws,{type:'info',text:'フレンド申請を送信しました'});return;
  }
  if(msg.type==='friend_answer'){
   const from=String(msg.from||'').toUpperCase(),target=look(from),key=user.code+':'+from,expiration=friendRequests.get(key);friendRequests.delete(key);
   if(!target||!expiration||expiration<Date.now())return fail(ws,'申請の期限が切れました');
   if(msg.accept===true){user.friends.add(from);target.friends.add(user.code);user.friendClaims.add(from);target.friendClaims.add(user.code);broadcastFriends(user);broadcastFriends(target);deliver(from,{type:'info',text:user.name+'さんとフレンドになりました'});}else deliver(from,{type:'info',text:'フレンド申請は承認されませんでした'});return;
  }
  if(msg.type==='cancel_invite'){for(const [key,inv] of invites)if(inv.from===user.code){invites.delete(key);deliver(inv.to,{type:'info',text:'招待がキャンセルされました'});}return;}
  if(msg.type==='invite'){
   if(Date.now()-user.lastInvite<3000)return fail(ws,'招待は3秒あけてください');user.lastInvite=Date.now();const to=String(msg.to||'').toUpperCase(),target=look(to),mode=msg.mode==='battle'?'battle':'flight';
   if(!target||!sockets.get(to)||!user.friends.has(to)||!target.friends.has(user.code))return fail(ws,'オンラインのフレンドを選んでください');
   if(user.room||target.room)return fail(ws,'誰かが別のフライトに参加しています');
   invites.set(to+':'+user.code,{from:user.code,to,mode,until:Date.now()+60000});
   deliver(to,{type:'invite_request',from:profile(user),mode});send(ws,{type:'invite_sent',to,mode});return;
  }
  if(msg.type==='invite_answer'){
   const from=String(msg.from||'').toUpperCase(),key=user.code+':'+from,inv=invites.get(key);invites.delete(key);
   const target=look(from);
   if(!inv||!target||!sockets.get(from)||inv.until<Date.now()||user.room||target.room)return fail(ws,'招待が終了しました');
   if(msg.accept!==true){deliver(from,{type:'invite_rejected',by:user.code});return;}
   const id=crypto.randomBytes(6).toString('hex'),room={id,a:from,b:user.code,mode:inv.mode,phase:'plane',planes:{},course:null,chosenCourses:{},lastPositions:{},scores:{[from]:0,[user.code]:0}};
   rooms.set(id,room);target.room=id;user.room=id;syncRoom(room);return;
  }
  const room=inRoom(user);if(!room)return fail(ws,'フライトに参加していません');
  const other=peer(room,user.code);
  if(msg.type==='plane'){
   if(room.phase!=='plane'||!['a400m','plain','starship'].includes(msg.plane))return;
   room.planes[user.code]=msg.plane;syncRoom(room);
   if(room.planes[room.a]&&room.planes[room.b]){room.phase='course';syncRoom(room);}return;
  }
  if(msg.type==='course'){
   if(room.phase!=='course'||!['coast','island','sunset','night'].includes(msg.course))return;
   room.chosenCourses[user.code]=msg.course;syncRoom(room);
   if(room.chosenCourses[room.a]&&room.chosenCourses[room.b]){
    room.course=room.chosenCourses[room.a];room.phase='playing';syncRoom(room);for(const c of [room.a,room.b])deliver(c,{type:'start_game',room:roomState(room)});
   }return;
  }
  if(msg.type==='state'){
   if(room.phase!=='playing')return;
   if(Date.now()-user.lastState<1750)return;
   if(!Array.isArray(msg.data)||msg.data.length!==12||!msg.data.every(v=>Number.isFinite(v)&&Math.abs(v)<1e7))return;
   user.lastState=Date.now();room.lastPositions[user.code]=msg.data.slice(0,3);
   deliver(other,{type:'state',from:user.code,data:msg.data});return;
  }
  if(msg.type==='chat'){
   if(room.phase!=='playing')return;
   const body=String(msg.text||'').trim().slice(0,180);if(!body||Date.now()-user.lastChat<700)return;user.lastChat=Date.now();
   for(const code of [room.a,room.b])deliver(code,{type:'chat',from:profile(user),text:body});return;
  }
  if(msg.type==='pulse'){
   if(room.phase!=='playing'||room.mode!=='battle'||Date.now()-user.lastPulse<1200)return;
   user.lastPulse=Date.now();const a=room.lastPositions[user.code],b=room.lastPositions[other];let hit=false;
   if(a&&b)hit=Math.hypot(a[0]-b[0],a[1]-b[1],a[2]-b[2])<220;
   if(hit)room.scores[user.code]++;
   for(const code of [room.a,room.b])deliver(code,{type:'pulse',from:user.code,hit,scores:room.scores});return;
  }
  if(msg.type==='leave')endRoom(room,user.code);
 });
 ws.on('close',()=>{if(user&&sockets.get(user.code)===ws){sockets.delete(user.code);broadcastFriends(user);const room=inRoom(user);if(room){deliver(peer(room,user.code),{type:'peer_offline'});setTimeout(()=>{if(!sockets.get(user.code)&&inRoom(user)===room)endRoom(room,user.code);},30000);}}});
});
setInterval(()=>{for(const ws of wss.clients){if(!ws.isAlive){ws.terminate();continue;}ws.isAlive=false;ws.ping();}for(const [k,v]of invites)if(v.until<Date.now())invites.delete(k);for(const [k,v]of friendRequests)if(v<Date.now())friendRequests.delete(k);},30000).unref();
const port=Number(process.env.PORT||10000);server.listen(port,'0.0.0.0',()=>console.log('A400M multiplayer server listening on '+port));
