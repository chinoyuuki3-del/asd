/* A400M ONLINE v0.4 — UI, friend requests, invite/accept, low-bandwidth aircraft positions. */
(()=>{'use strict';
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const profileKey='a400mOnlineName',tokenKey='a400mOnlineToken';
let name=localStorage.getItem(profileKey)||'',token=localStorage.getItem(tokenKey)||'',me=null,ws=null,friends=[],room=null,screen='closed',inviteMode='flight',pendingRoom=null,inviteStarted=0,sendTick=null,reconnectTimer=null,serverReady=false,chatMsgs=[],audioStarted=false,lastMyPlane='a400m';
if(!token){const bytes=new Uint8Array(24);crypto.getRandomValues(bytes);token=Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');localStorage.setItem(tokenKey,token);}
const overlay=document.createElement('div');overlay.id='mpLayer';overlay.innerHTML='<div id="mpPanel"></div>';document.body.appendChild(overlay);
const chat=document.createElement('div');chat.className='mpChat';chat.id='mpChat';chat.style.display='none';chat.innerHTML='<div class="mpChatHead"><span id="mpRoomLabel">✈️ ONLINE RADIO</span><span><button class="mpBtn mpGhost" data-op="leave" style="font-size:11px;padding:5px 7px">退出</button></span></div><div id="mpChatLog" class="mpChatLog" role="log" aria-live="polite"></div><form id="mpChatForm" class="mpChatForm"><input id="mpChatInput" placeholder="友達にメッセージ…" maxlength="180" autocomplete="off"><button type="submit">送信</button></form>';document.body.appendChild(chat);
const statusHud=document.createElement('div');statusHud.className='mpHud';statusHud.id='mpHud';statusHud.style.display='none';document.body.appendChild(statusHud);
let prompt=null;let inviteTimer=null;
const audio=new Audio('audio/suretigai.mp3');audio.loop=true;audio.volume=.17;audio.preload='none';
function notifyText(txt){const e=document.createElement('div');e.className='mpToast';e.textContent=txt;document.body.appendChild(e);setTimeout(()=>e.remove(),3400);}
function maybeNotify(title,body){notifyText(title+' — '+body);if('Notification' in window&&Notification.permission==='granted'&&document.hidden){try{new Notification(title,{body,tag:'a400m-online-request'});}catch(e){}}}
function render(html){$('mpPanel').innerHTML=html;}
function standard(title,content,more=''){return `<div class="mpTop"><span class="mpKicker">◈ A400M FLIGHT LAB // ONLINE NETWORK</span><button class="mpBtn mpGhost" data-op="close">✕ 戻る</button></div><h1 class="mpTitle">${title}</h1>${content}${more}`;}
function dots(){return '<div class="mpDots"><i></i><i></i><i></i><i></i><i></i></div>';}
function openOverlay(){overlay.classList.add('visible');}
function closeOverlay(){if(room?.phase==='playing')return;overlay.classList.remove('visible');screen='closed';}
async function openMultiplayer(){if(screen!=='closed'){openOverlay();return;}
 screen='first';openOverlay();$('welcome').style.display='none';
 try{audio.play().then(()=>{audioStarted=true;}).catch(()=>{});}catch(e){}
 render(standard('CONNECTING WORLDS',`<div class="mpVs"><div class="mpFace">👨‍✈️</div><div class="mpNet">◎</div><div class="mpFace right">👩‍✈️</div></div><div style="text-align:center" class="mpKicker">INTERNET CONNECTION · 5 SECOND INTRO</div>${dots()}<p class="mpSub" style="text-align:center;margin:auto">インターネットへ接続する演出中…</p>`));
 await wait(5000);if(screen!=='first')return;
 if(!name){screen='name';render(standard('名前を付けましょう',`<p class="mpSub">これがオンラインアカウントの表示名です。いつでも変更できます。</p><form id="mpNameForm"><input id="mpNameInput" class="mpField" maxlength="18" placeholder="パイロット名を入力" autocomplete="nickname" required><div class="mpActions"><button type="submit" class="mpBtn mpPrimary">この名前で決定 →</button></div></form>`));}
 else await secondIntro();}
async function secondIntro(){screen='second';render(standard('フライトネットワーク起動',`<div class="mpVs"><div class="mpFace">✈️</div><div class="mpNet">◉</div><div class="mpFace right">🌐</div></div>${dots()}<p class="mpSub" style="text-align:center;margin:auto">アカウントとネットワークを準備しています…</p>`));await wait(5000);if(screen!=='second')return;
 screen='go';render('<div style="height:290px;display:grid;place-items:center"><div class="mpGo">さあ、始めよう！</div></div>');await wait(1850);if(screen!=='go')return;screen='menu';connect();menu();}
function connText(){return serverReady?'<span class="mpBadge">● ONLINE</span>':'<span class="mpBadge" style="color:#ffca9d">○ 接続待ち</span>';}
function menu(){screen='menu';const code=me?.code||'--------';render(standard('FLIGHT NETWORK',`<p class="mpSub">友達と同じ空を飛ぼう。サーバーへ送る機体の位置は<strong>2秒に1回</strong>。チャットは送信したときだけ通信するよ。</p><div class="mpIdentity"><div><div class="mpMini">PILOT PROFILE</div><b>${esc(name)}</b>　${connText()}<div class="mpInfo">あなたのフレンドコード： <span class="mpCode">${esc(code)}</span></div></div><div class="mpActions" style="margin:0"><button data-op="copy" class="mpBtn">コードをコピー</button><button data-op="rename" class="mpBtn mpGhost">名前変更</button></div></div><div class="mpRows" style="margin-top:20px"><button class="mpChoice" data-op="friends"><span class="bigicon">👥</span><strong>友達追加</strong><small>フレンドコードを交換</small></button><button class="mpChoice" data-op="invite-battle"><span class="bigicon">⚡</span><strong>対戦</strong><small>光るエネルギーパルス</small></button><button class="mpChoice" data-op="invite-flight"><span class="bigicon">✈️</span><strong>飛び合い</strong><small>一緒に空を飛ぶ</small></button></div><div class="mpActions"><button data-op="allow-notify" class="mpBtn mpGhost">🔔 通知を許可</button><button data-op="music" class="mpBtn mpGhost">♫ BGM ON/OFF</button></div><p class="mpInfo">通知はこのWebサイトを開いている間に受け取れます。ページを完全に閉じた状態でのプッシュ通知には未対応です。</p>`));}
function friendsScreen(mode){inviteMode=mode||inviteMode;screen='friends';const list=friends.map(p=>`<div class="mpFriend"><div style="display:flex;gap:12px;align-items:center"><div class="mpAvatar">👨‍✈️</div><div><div class="mpFriendName">${esc(p.name)}</div><div class="mpInfo">${esc(p.code)} · <span class="${p.online?'mpOnline':'mpOffline'}">${p.online?'● オンライン':'○ オフライン'}</span></div></div></div><div><button class="mpBtn ${p.online?'mpPrimary':''}" data-op="invite-person" data-code="${esc(p.code)}" ${p.online?'':'disabled'}>${inviteMode==='battle'?'⚡ 対戦に招待':'✈️ 飛行に招待'}</button></div></div>`).join('')||'<p class="mpSub">フレンドはまだいません。相手のフレンドコードを入力して申請しよう！</p>';
 render(standard('友達ネットワーク',`<p class="mpSub">自分のコード <b class="mpCode">${esc(me?.code||'--------')}</b> を友達に伝え、お互いに承認すると招待できるよ。</p><div class="mpCard"><div class="mpMini">FRIEND REQUEST</div><form id="mpFriendForm" class="mpActions"><input id="mpFriendCode" class="mpField" style="flex:1" maxlength="8" placeholder="相手の8桁フレンドコード" required><button class="mpBtn mpPrimary" type="submit">追加リクエストを送る</button></form></div><div class="mpCard" style="margin-top:14px"><div class="mpMini">FRIENDS · ${friends.length}</div>${list}</div><div class="mpActions"><button data-op="menu" class="mpBtn mpGhost">← メニューへ</button></div>`));}
function send(obj){if(ws?.readyState===WebSocket.OPEN){ws.send(JSON.stringify(obj));return true;}notifyText('サーバーに接続していません');return false;}
function connect(){if(ws&&(ws.readyState===WebSocket.OPEN||ws.readyState===WebSocket.CONNECTING))return;
 if(location.protocol==='file:'){serverReady=false;notifyText('オンラインプレイはRender上のURLまたはローカルサーバーから開いてね');return;}
 const url=(location.protocol==='https:'?'wss://':'ws://')+location.host+'/ws';try{ws=new WebSocket(url);}catch(e){notifyText('ネットワークに接続できません');return;}
 ws.addEventListener('open',()=>{serverReady=true;send({type:'hello',name,token,friends:JSON.parse(localStorage.getItem('a400mFriendCodes')||'[]')});if(screen==='menu')menu();});
 ws.addEventListener('message',e=>{let data;try{data=JSON.parse(e.data);}catch{return;}handle(data);});
 ws.addEventListener('close',()=>{serverReady=false;me=null;if(screen==='menu')menu();if(screen==='friends')friendsScreen();if(screen==='playing')notifyText('接続が切れました。再接続中…');clearTimeout(reconnectTimer);reconnectTimer=setTimeout(connect,2500);});
 ws.addEventListener('error',()=>{serverReady=false;});}
function showPrompt(title,body,onYes,onNo){if(prompt)prompt.remove();prompt=document.createElement('div');prompt.className='mpPrompt';prompt.innerHTML=`<div class="mpCard"><div class="mpKicker">FLIGHT NETWORK INCOMING</div><h2>${esc(title)}</h2><p class="mpSub">${esc(body)}</p><div class="mpActions"><button class="mpBtn mpPrimary" id="mpAccept">許可する</button><button class="mpBtn mpGhost" id="mpDeny">断る</button></div></div>`;document.body.appendChild(prompt);$('mpAccept').onclick=()=>{prompt.remove();prompt=null;onYes();};$('mpDeny').onclick=()=>{prompt.remove();prompt=null;onNo();};}
function handle(msg){switch(msg.type){
 case 'hello':me=msg.me;friends=msg.friends||[];if(screen==='menu')menu();if(msg.room){room=msg.room;handleRoom();}break;
 case 'me':me=msg.me;if(screen==='menu')menu();break;
 case 'friends':friends=msg.list||[];localStorage.setItem('a400mFriendCodes',JSON.stringify(friends.map(f=>f.code)));if(screen==='friends')friendsScreen();break;
 case 'presence':friends=friends.map(f=>f.code===msg.user.code?msg.user:f);if(screen==='friends')friendsScreen();break;
 case 'friend_request':maybeNotify('友達追加リクエスト',msg.from.name+'さんから申請');showPrompt('友達追加の申請',msg.from.name+'さん（'+msg.from.code+'）からフレンドリクエストが届いたよ。',()=>send({type:'friend_answer',from:msg.from.code,accept:true}),()=>send({type:'friend_answer',from:msg.from.code,accept:false}));break;
 case 'invite_request':maybeNotify('遊ぶリクエストがあります',msg.from.name+'さんから '+(msg.mode==='battle'?'対戦':'飛行')+'のお誘い');showPrompt('遊ぶリクエストがあります',msg.from.name+'さんから '+(msg.mode==='battle'?'⚡ 対戦':'✈️ 飛び合い')+' に招待されました！',()=>{send({type:'invite_answer',from:msg.from.code,accept:true});screen='wait';openOverlay();showWaiting('招待を許可しました。相手の準備を待っています…');},()=>send({type:'invite_answer',from:msg.from.code,accept:false}));break;
 case 'invite_sent':inviteStarted=Date.now();screen='wait';openOverlay();showWaiting('友達からの返事を受信しています…');break;
 case 'invite_rejected':screen='friends';notifyText('相手が招待を辞退しました');friendsScreen();break;
 case 'room':room=msg.room;handleRoom();break;
 case 'room_closed':room=null;clearInterval(sendTick);sendTick=null;chat.style.display='none';statusHud.style.display='none';window.FLIGHT_BRIDGE?.endMulti();notifyText('フライトが終了しました');screen='menu';openOverlay();menu();break;
 case 'peer_offline':notifyText('友達が切断されました。復帰を待っています…');break;
 case 'state':if(room?.phase==='playing')window.FLIGHT_BRIDGE?.setRemote(msg.data);break;
 case 'start_game':room=msg.room;startFlight();break;
 case 'chat':chatMsgs.push({name:msg.from.name,text:msg.text});if(chatMsgs.length>100)chatMsgs.shift();renderChat();break;
 case 'pulse':if(msg.from!==me?.code)flashPulse();if(room?.mode==='battle'){statusHud.textContent=`⚡ 対戦中 ｜ ${esc(me?.name)} ${msg.scores[me.code]||0} : ${msg.scores[otherCode()]||0} 友達`;if(msg.hit)notifyText(msg.from===me.code?'ヒット！ +1':'相手からヒット！');}break;
 case 'replaced':notifyText('別の画面でログインしました');break;
 case 'info':notifyText(msg.text);break;
 case 'error':notifyText('サーバー: '+msg.reason);break;
 }}
function otherCode(){return room?.host===me?.code?room?.guest:room?.host;}
function handleRoom(){if(!room||!me)return;const role=me.code===room.host?'host':'guest';if(room.phase==='plane'){
 if(screen==='wait'&&role==='host'&&Date.now()-inviteStarted<10000){pendingRoom=room;if(!inviteTimer){const remaining=10000-(Date.now()-inviteStarted);inviteTimer=setTimeout(()=>{inviteTimer=null;if(room?.phase==='plane'&&screen==='wait')planeSelection();},remaining);}return;}
 planeSelection();
 }else if(room.phase==='course')courseSelection();else if(room.phase==='playing'){if(screen!=='playing')startFlight();}}
function showWaiting(text){render(standard('友達から受信しています',`<div class="mpWaiting"><div class="mpVs"><div class="mpFace">👨‍✈️</div><div class="mpNet">◉</div><div class="mpFace right">👩‍✈️</div></div><div class="mpKicker">WAITING FOR FRIEND · CONNECTION</div>${dots()}<p class="mpSub" style="margin:auto">${esc(text)}</p><div class="mpActions" style="justify-content:center"><button data-op="cancel-invite" class="mpBtn mpGhost">キャンセル</button></div></div>`));}
const planes=[['a400m','✈️','A400M','大型輸送機・リアルな3Dモデル'],['plain','🛩️','PLAIN','送ってくれたOBJモデル'],['starship','🚀','STARSHIP 2','送ってくれた宇宙機モデル']];
function planeSelection(){if(!room)return;screen='plane';openOverlay();const selected=room.planes[me.code];render(standard('飛行機を選ぼう',`<p class="mpSub">2人とも同じ機体を選んでも大丈夫！双方の選択が終わるとコース画面に進むよ。</p><div class="mpRows">${planes.map(p=>`<button data-op="pick-plane" data-value="${p[0]}" class="mpChoice ${selected===p[0]?'selected':''}"><span class="bigicon">${p[1]}</span><strong>${p[2]}</strong><small>${p[3]}</small></button>`).join('')}</div><div class="mpStatus">${selected?'✓ 自分の機体選択完了':'自分の機体を選んでね'} · ${room.planes[otherCode()]?'✓ 相手も選択済み':'相手の選択を待機中'}</div>${dots()}<div class="mpActions"><button data-op="cancel-invite" class="mpBtn mpGhost">退出する</button></div>`));}
const courses=[['coast','☀️','海岸・昼','晴れた明るい空港'],['island','🏝️','島の上空','開放的な昼の飛行'],['sunset','🌇','夕焼け','オレンジ色の空'],['night','🌌','星空の夜','星・月・滑走路灯']];
function courseSelection(){if(!room)return;screen='course';openOverlay();const host=room.host===me.code?me:{code:room.host,name:friends.find(f=>f.code===room.host)?.name||'招待した人'};const guest=room.guest===me.code?me:{code:room.guest,name:friends.find(f=>f.code===room.guest)?.name||'招待された人'};
 render(standard('コースを決めよう',`<p class="mpSub">左側が招待した人、右側が招待された人。2人が選び終わると同時にスタート！ 違うコースなら招待した人の選択を優先するよ。</p><div class="mpSplit"><div class="mpCard"><div class="mpMini">LEFT / HOST</div><strong>👨‍✈️ ${esc(host.name)}</strong><div class="mpStatus">${esc(room.chosenCourses[room.host]||'選択待ち')}</div></div><div class="mpCard"><div class="mpMini">RIGHT / GUEST</div><strong>👩‍✈️ ${esc(guest.name)}</strong><div class="mpStatus">${esc(room.chosenCourses[room.guest]||'選択待ち')}</div></div></div><div class="mpRows" style="margin-top:18px">${courses.map(c=>`<button data-op="pick-course" data-value="${c[0]}" class="mpChoice ${room.chosenCourses[me.code]===c[0]?'selected':''}"><span class="bigicon">${c[1]}</span><strong>${c[2]}</strong><small>${c[3]}</small></button>`).join('')}</div>${dots()}<div class="mpActions"><button data-op="cancel-invite" class="mpBtn mpGhost">退出</button></div>`));}
function startFlight(){if(!room||!me)return;screen='playing';overlay.classList.remove('visible');chat.style.display='block';statusHud.style.display='block';chatMsgs=[];renderChat();const myPlane=room.planes[me.code]||'a400m',theirPlane=room.planes[otherCode()]||'a400m';const host=me.code===room.host;
 window.FLIGHT_BRIDGE?.startMulti({host,course:room.course||'coast',myPlane,theirPlane});
 statusHud.textContent=room.mode==='battle'?'⚡ 対戦中 ｜ Bキーで光のパルス':'✈️ 2人の空を飛行中 ｜ 位置送信：2秒ごと';
 $('mpRoomLabel').textContent=room.mode==='battle'?'⚡ ENERGY MATCH · Bで発射':'✈️ FLIGHT RADIO · 2秒同期';
 clearInterval(sendTick);const transmit=()=>{if(room?.phase!=='playing')return;const sample=window.FLIGHT_BRIDGE?.sample();if(sample)send({type:'state',data:sample});};transmit();sendTick=setInterval(transmit,2000);
 notifyText('2人のフライト開始！ Cで視点変更 / Nで昼夜切替');}
function renderChat(){const el=$('mpChatLog');if(!el)return;el.innerHTML=chatMsgs.map(v=>`<p><b>${esc(v.name)}:</b> ${esc(v.text)}</p>`).join('');el.scrollTop=el.scrollHeight;}
function flashPulse(){const x=document.createElement('div');x.className='mpBulletFlash';document.body.appendChild(x);setTimeout(()=>x.remove(),320);}
function firePulse(){if(screen!=='playing'||room?.mode!=='battle')return;send({type:'pulse'});flashPulse();}
window.addEventListener('keydown',e=>{if(!e.target.closest?.('input,textarea,[contenteditable]')&&e.code==='KeyB'&&screen==='playing'&&!e.repeat){e.preventDefault();firePulse();}});
$('mpChatForm').addEventListener('submit',e=>{e.preventDefault();const el=$('mpChatInput'),text=el.value.trim();if(text){send({type:'chat',text});el.value='';el.focus();}});
document.addEventListener('click',e=>{const btn=e.target.closest('[data-op]');if(!btn)return;const op=btn.dataset.op,code=btn.dataset.code,val=btn.dataset.value;
 if(op==='close')closeOverlay();else if(op==='menu')menu();else if(op==='friends')friendsScreen('flight');else if(op==='invite-battle')friendsScreen('battle');else if(op==='invite-flight')friendsScreen('flight');else if(op==='invite-person')send({type:'invite',to:code,mode:inviteMode});else if(op==='copy'){navigator.clipboard?.writeText(me?.code||'').then(()=>notifyText('コードをコピーしたよ')).catch(()=>notifyText('コード '+me?.code));}
 else if(op==='rename'){name='';localStorage.removeItem(profileKey);screen='name';render(standard('名前を変えよう',`<form id="mpNameForm"><input id="mpNameInput" class="mpField" maxlength="18" placeholder="新しい名前" required><div class="mpActions"><button type="submit" class="mpBtn mpPrimary">決定</button></div></form>`));}
 else if(op==='allow-notify'){'Notification' in window?Notification.requestPermission().then(x=>notifyText(x==='granted'?'通知を許可しました':'通知は許可されませんでした')):notifyText('このブラウザは通知に未対応です');}
 else if(op==='music'){if(audio.paused){audio.play().catch(()=>notifyText('BGMを再生できません'))}else audio.pause();}
 else if(op==='pick-plane'){lastMyPlane=val;send({type:'plane',plane:val});window.FLIGHT_BRIDGE?.loadPlane(val).catch(()=>notifyText('機体モデルのロードに失敗しました'));}
 else if(op==='pick-course')send({type:'course',course:val});
 else if(op==='cancel-invite'||op==='leave'){if(room)send({type:'leave'});else {send({type:'cancel_invite'});screen='menu';menu();}if(op==='leave'&&!room){chat.style.display='none';statusHud.style.display='none';}}
});
document.addEventListener('submit',e=>{if(e.target.id==='mpNameForm'){e.preventDefault();const n=$('mpNameInput')?.value.trim();if(!n)return;name=n.slice(0,18);localStorage.setItem(profileKey,name);if(serverReady)send({type:'rename',name});secondIntro();}
 if(e.target.id==='mpFriendForm'){e.preventDefault();const code=$('mpFriendCode')?.value.trim().toUpperCase();if(code)send({type:'friend_add',code});}});
const top=$('quality')?.parentElement;
if(top){const btn=document.createElement('button');btn.id='multiEntry';btn.textContent='🌐 マルチプレイ';btn.addEventListener('click',openMultiplayer);top.prepend(btn);}
const welcomeStart=$('start');if(welcomeStart){const b=document.createElement('button');b.id='multiWelcome';b.textContent='👥 マルチプレイ — 友達と一緒に飛ぶ';b.addEventListener('click',openMultiplayer);welcomeStart.insertAdjacentElement('afterend',b);}
})();
