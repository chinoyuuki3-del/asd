/* Offline protocol test: mocks the ws dependency without a browser or network. */
const assert=require('node:assert/strict');const Events=require('node:events'),Module=require('node:module');
class WSS extends Events{constructor(){super();this.clients=new Set();global.__testWSS=this;}};
const original=Module._load;Module._load=function(req,...args){if(req==='ws')return {WebSocketServer:WSS,WebSocket:{OPEN:1}};return original.call(this,req,...args);};
process.env.PORT='17990';require('./server.js');Module._load=original;
class Socket extends Events{constructor(){super();this.readyState=1;this.out=[];global.__testWSS.clients.add(this);global.__testWSS.emit('connection',this);}send(v){this.out.push(JSON.parse(v));}ping(){}close(){this.readyState=3;this.emit('close');}}
function x(sock,payload){sock.emit('message',Buffer.from(JSON.stringify(payload)));}
function last(sock,type){return sock.out.filter(p=>p.type===type).at(-1);}
const a=new Socket(),b=new Socket();
x(a,{type:'hello',token:'a'.repeat(48),name:'Alpha'});
x(b,{type:'hello',token:'b'.repeat(48),name:'Bravo'});
const aa=last(a,'hello').me.code,bb=last(b,'hello').me.code;
assert.ok(aa!==bb);
x(a,{type:'friend_add',code:bb});assert.equal(last(b,'friend_request').from.code,aa);
x(b,{type:'friend_answer',from:aa,accept:true});assert.equal(last(a,'friends').list[0].code,bb);
x(a,{type:'invite',to:bb,mode:'flight'});assert.equal(last(b,'invite_request').from.code,aa);
x(b,{type:'invite_answer',from:aa,accept:true});assert.equal(last(a,'room').room.phase,'plane');
x(a,{type:'plane',plane:'a400m'});x(b,{type:'plane',plane:'starship'});assert.equal(last(a,'room').room.phase,'course');
x(a,{type:'course',course:'night'});x(b,{type:'course',course:'coast'});assert.equal(last(a,'start_game').room.course,'night');
x(a,{type:'state',data:Array(12).fill(1)});assert.ok(last(b,'state'));
x(a,{type:'chat',text:'こんにちは！'});assert.equal(last(b,'chat').text,'こんにちは！');
x(a,{type:'leave'});assert.equal(last(a,'room_closed').by,aa);
console.log('OK: friend request -> accept -> invite -> plane -> course -> 2-player state/chat -> leave');
process.exit(0);
